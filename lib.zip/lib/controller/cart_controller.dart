// lib/controller/cart_controller.dart
import 'package:flutter/foundation.dart';
import '../core/models/menu_models.dart';

class CartController extends ChangeNotifier {
  final Map<String, int> _qty = {};
  final Map<String, MenuItemModel> _items = {};
  final Map<String, String> _specs = {}; // <-- specs por itemId

  void add(MenuItemModel item) {
    _items[item.id] = item;
    _qty.update(item.id, (v) => v + 1, ifAbsent: () => 1);
    notifyListeners();
  }

  void dec(String id) {
    if (!_qty.containsKey(id)) return;
    final v = _qty[id]! - 1;
    if (v <= 0) {
      _qty.remove(id);
      _items.remove(id);
      _specs.remove(id);
    } else {
      _qty[id] = v;
    }
    notifyListeners();
  }

  int qty(String id) => _qty[id] ?? 0;

  int get totalCents =>
      _qty.entries.fold(0, (s, e) => s + (_items[e.key]!.priceCents * e.value));

  /// Aquí añadimos specs en cada línea del pedido
  List<Map<String, dynamic>> toOrderItems() => _qty.entries
      .map((e) => {
    'itemId': e.key,
    'name': _items[e.key]!.name,
    'unitCents': _items[e.key]!.priceCents,
    'qty': e.value,
    'lineCents': _items[e.key]!.priceCents * e.value,
    'specs': (_specs[e.key] ?? '').toString(),
  })
      .toList();

  void setSpec(String id, String? spec) {
    if (spec == null || spec.trim().isEmpty) {
      _specs.remove(id);
    } else {
      _specs[id] = spec.trim();
    }
    notifyListeners();
  }

  String? getSpec(String id) => _specs[id];

  void clear() {
    _qty.clear();
    _items.clear();
    _specs.clear();
    notifyListeners();
  }
}
