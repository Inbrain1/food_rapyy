// lib/screeens/waiter_order_detail_screen.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class WaiterOrderDetailScreen extends StatefulWidget {
  const WaiterOrderDetailScreen({super.key, required this.orderRef});
  final DocumentReference<Map<String, dynamic>> orderRef;

  @override
  State<WaiterOrderDetailScreen> createState() => _WaiterOrderDetailScreenState();
}

class _WaiterOrderDetailScreenState extends State<WaiterOrderDetailScreen> {
  String _method = 'cash'; // 'cash' | 'yape'
  final _cashCtrl = TextEditingController();

  @override
  void dispose() {
    _cashCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: widget.orderRef.snapshots(),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        final data = snap.data!.data();
        if (data == null) {
          return const Scaffold(body: Center(child: Text('Pedido no disponible')));
        }

        final table = (data['table'] ?? '').toString();
        final takeout = (data['takeout'] ?? false) as bool;
        final status = (data['status'] ?? '').toString();
        final items = ((data['items'] as List?) ?? const []).cast<Map<String, dynamic>>();
        final subtotal = (data['subtotalCents'] ?? 0) as int;
        final discount = (data['discountCents'] ?? 0) as int;
        final total = (data['totalCents'] ?? (subtotal - discount)) as int;
        final notes = (data['notes'] ?? '').toString();
        final isPending = status == 'pendiente';

        final cashCents = _parseSolesToCents(_cashCtrl.text);
        final changeCents = (cashCents - total) < 0 ? 0 : cashCents - total;
        final canCharge = isPending && (_method == 'yape' || cashCents >= total);

        return Scaffold(
          appBar: AppBar(
            leading: BackButton(onPressed: () => Navigator.pop(context)),
            title: const Text('Detalle del pedido'),
          ),
          body: Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  if (takeout)
                    const Text('Para llevar', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700))
                  else
                    Text('Mesa $table', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                  const Spacer(),
                  Chip(label: Text(status)),
                ]),
                const SizedBox(height: 8),
                const Text('Items', style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 6),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
                  ),
                  child: ListView.separated(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(8),
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (_, i) {
                      final it = items[i];
                      final name = (it['name'] ?? '').toString();
                      final qty = (it['qty'] ?? 1) as int;
                      final unit = (it['unitCents'] ?? 0) as int;
                      final line = (it['lineCents'] ?? unit * qty) as int;
                      final canEdit = isPending;
                      final specs = (it['specs'] ?? '').toString();

                      return Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(vertical: 6),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(name, style: const TextStyle(fontWeight: FontWeight.w600)),
                                  Text('$qty x ${formatPEN(unit)}', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                                  if (specs.isNotEmpty)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 6),
                                      child: Text(specs, style: TextStyle(fontStyle: FontStyle.italic, color: Theme.of(context).colorScheme.onSurfaceVariant)),
                                    ),
                                ],
                              ),
                            ),
                          ),
                          Text(formatPEN(line)),
                          const SizedBox(width: 8),
                          IconButton(
                            tooltip: 'Quitar este ítem',
                            onPressed: canEdit ? () => _removeLine(it) : null,
                            icon: const Icon(Icons.close),
                          ),
                        ],
                      );
                    },
                  ),
                ),
                if (notes.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.note, size: 18),
                      const SizedBox(width: 6),
                      Expanded(child: Text(notes)),
                    ],
                  ),
                ],
                const SizedBox(height: 10),
                Row(
                  children: [
                    const Spacer(),
                    Text('Total:  ', style: TextStyle(fontWeight: FontWeight.w600, color: Theme.of(context).colorScheme.primary)),
                    Text(formatPEN(total), style: TextStyle(fontWeight: FontWeight.w700, color: Theme.of(context).colorScheme.primary)),
                  ],
                ),
                const SizedBox(height: 16),
                const Text('Método de pago', style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 6),
                Wrap(spacing: 8, children: [
                  FilterChip(
                    selected: _method == 'cash',
                    onSelected: isPending ? (_) => setState(() => _method = 'cash') : null,
                    label: const Text('Efectivo'),
                  ),
                  FilterChip(
                    selected: _method == 'yape',
                    onSelected: isPending ? (_) => setState(() => _method = 'yape') : null,
                    label: const Text('Yape'),
                  ),
                ]),
                const SizedBox(height: 8),
                TextField(
                  controller: _cashCtrl,
                  enabled: isPending && _method == 'cash',
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Recibido S/',
                    hintText: 'Ej: 100 o 100.50',
                  ),
                  onChanged: (_) => setState(() {}),
                ),
                const SizedBox(height: 6),
                Align(
                  alignment: Alignment.centerRight,
                  child: Text('Vuelto: ${formatPEN(changeCents)}'),
                ),
                const Spacer(),
                Row(
                  children: [
                    OutlinedButton.icon(
                      onPressed: isPending ? _cancelOrder : null,
                      icon: const Icon(Icons.cancel_outlined),
                      label: const Text('Cancelar pendiente'),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton(
                        onPressed: canCharge ? () => _charge(total, cashCents, changeCents) : null,
                        child: const Text('Cobrar'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ===== Utils =====

  // "100" -> 10000 ; "100.5" -> 10050 ; "100,50" -> 10050
  int _parseSolesToCents(String input) {
    final t = input.trim().replaceAll(',', '.');
    if (t.isEmpty) return 0;
    final v = double.tryParse(t);
    if (v == null) return 0;
    final cents = (v * 100).round();
    if (cents < 0) return 0;
    return cents;
  }

  Future<T> _withBlockingLoader<T>(Future<T> Function() task) async {
    if (!mounted) return await task();
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black45,
      builder: (_) => const _BlockingLoader(),
    );
    try {
      final r = await task();
      return r;
    } finally {
      if (mounted) Navigator.of(context, rootNavigator: true).pop();
    }
  }

  Future<void> _removeLine(Map<String, dynamic> line) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Quitar ítem'),
        content: Text('¿Deseas quitar "${line['name']}" del pedido?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('No')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Sí, quitar')),
        ],
      ),
    );
    if (confirm != true) return;

    await _withBlockingLoader(() async {
      await FirebaseFirestore.instance.runTransaction((tx) async {
        final snap = await tx.get(widget.orderRef);
        final data = snap.data()!;
        final items = ((data['items'] as List?) ?? const []).cast<Map<String, dynamic>>().toList();

        final idx = items.indexWhere((m) => (m['itemId'] ?? '') == (line['itemId'] ?? ''));
        if (idx == -1) return;

        items.removeAt(idx);

        final newSubtotal = items.fold<int>(0, (s, it) {
          final q = (it['qty'] ?? 1) as int;
          final u = (it['unitCents'] ?? 0) as int;
          final ln = (it['lineCents'] ?? (u * q)) as int;
          return s + ln;
        });
        final discount = (data['discountCents'] ?? 0) as int;
        final newTotal = (newSubtotal - discount);
        final baseUpdate = <String, dynamic>{
          'items': items,
          'subtotalCents': newSubtotal,
          'totalCents': newTotal < 0 ? 0 : newTotal,
          'updatedAt': FieldValue.serverTimestamp(),
        };

        if (items.isEmpty) {
          baseUpdate['status'] = 'cancelado';
          baseUpdate['paymentStatus'] = 'cancelado';
        }
        tx.update(widget.orderRef, baseUpdate);
      });
    });
  }

  Future<void> _cancelOrder() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Cancelar pedido'),
        content: const Text('¿Seguro que deseas cancelar todo el pedido?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('No')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Sí, cancelar')),
        ],
      ),
    );
    if (ok != true) return;

    await _withBlockingLoader(() async {
      await widget.orderRef.update({
        'status': 'cancelado',
        'paymentStatus': 'cancelado',
        'updatedAt': FieldValue.serverTimestamp(),
      });
    });
    if (mounted) Navigator.pop(context);
  }

  Future<void> _charge(int totalCents, int cashReceivedCents, int changeCents) async {
    final payment = _method == 'cash'
        ? {
      'method': 'cash',
      'amountCents': totalCents,
      'cashReceivedCents': cashReceivedCents,
      'changeCents': changeCents,
      'yapeRef': null,
    }
        : {
      'method': 'yape',
      'amountCents': totalCents,
      'cashReceivedCents': 0,
      'changeCents': 0,
      'yapeRef': null,
    };

    await _withBlockingLoader(() async {
      await widget.orderRef.update({
        'status': 'pagado',
        'paymentStatus': 'pagado',
        'payment': payment,
        'paidAt': FieldValue.serverTimestamp(), // <-- clave para Historial
        'updatedAt': FieldValue.serverTimestamp(),
      });
    });
    if (mounted) Navigator.pop(context);
  }
}

class _BlockingLoader extends StatelessWidget {
  const _BlockingLoader();

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: const Center(child: CircularProgressIndicator()),
    );
  }
}

String formatPEN(int cents) => 'S/ ${(cents / 100).toStringAsFixed(2)}';
