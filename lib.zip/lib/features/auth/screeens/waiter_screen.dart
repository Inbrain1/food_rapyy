import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:food_chifa/features/auth/screeens/waiter_new_screen.dart';

import '../../../core/services/auth_service.dart';
import '../../../core/services/orders_service.dart';
import '../widgets/add_order_card.dart';
import '../widgets/peding_table_sheet.dart';
import '../widgets/table_card.dart';

class WaiterScreen extends StatefulWidget {
  const WaiterScreen({super.key, required this.auth});
  final AuthService auth;

  @override
  State<WaiterScreen> createState() => _WaiterScreenState();
}

class _WaiterScreenState extends State<WaiterScreen> {
  final _orders = OrdersService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mozo'),
        actions: [
          IconButton(
            tooltip: 'Historial',
            onPressed: () => Navigator.of(context).pushNamed('/waiter/history'),
            icon: const Icon(Icons.history),
          ),
          IconButton(onPressed: () => widget.auth.logout(), icon: const Icon(Icons.logout)),
        ],
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _orders.watchRecent(limit: 200),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final docs = snap.data?.docs ?? const [];
          final pendingDocs = docs.where((d) => (d.data()['status'] ?? 'pendiente') == 'pendiente').toList();

          // agrupar por mesa y acumular ítems
          final Map<String, List<QueryDocumentSnapshot<Map<String, dynamic>>>> byTable = {};
          final Map<String, Map<String, int>> itemsByTable = {};

          for (final d in pendingDocs) {
            final data = d.data();
            final table = (data['table'] ?? '').toString();
            if (table.isEmpty) continue;

            byTable.putIfAbsent(table, () => []).add(d);

            final items = (data['items'] as List?)?.cast<Map<String, dynamic>>() ?? const [];
            final map = itemsByTable.putIfAbsent(table, () => {});
            for (final it in items) {
              final name = (it['name'] ?? '').toString();
              final qty = (it['qty'] is int) ? it['qty'] as int : 1;
              if (name.isEmpty) continue;
              map.update(name, (v) => v + qty, ifAbsent: () => qty);
            }
          }

          final tables = byTable.keys.toList()
            ..sort((a, b) {
              final ai = int.tryParse(a);
              final bi = int.tryParse(b);
              if (ai != null && bi != null) return ai.compareTo(bi);
              return a.compareTo(b);
            });

          return LayoutBuilder(
            builder: (context, c) {
              final w = c.maxWidth;
              int cross = 2;
              if (w >= 1200) cross = 5;
              else if (w >= 1000) cross = 4;
              else if (w >= 700) cross = 3;

              final cards = <Widget>[
                AddOrderCard(
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const WaiterNewOrderScreen()),
                  ),
                ),
                for (final t in tables)
                  TableCard(
                    table: t,
                    pendingCount: byTable[t]!.length,
                    items: _topItems(itemsByTable[t] ?? const {}, 99),
                    onOpen: () => showPendingTableSheet(
                      context: context,
                      table: t,
                      initialOrders: byTable[t]!,
                    ),
                  ),
              ];

              return GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: cross,
                  childAspectRatio: 1.2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                ),
                itemCount: cards.length,
                itemBuilder: (_, i) => cards[i],
              );
            },
          );
        },
      ),
    );
  }

  List<String> _topItems(Map<String, int> map, int take) {
    final list = map.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return list.take(take).map((e) => '${e.key} x${e.value}').toList();
  }
}
