// lib/screeens/waiter_new_order_screen.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';
import '../../../core/models/menu_models.dart';
import '../../../core/services/menu_services.dart';

class CartController extends ChangeNotifier {
  final Map<String, int> _qty = {};
  final Map<String, MenuItemModel> _items = {};
  final Map<String, String> _specs = {}; // specs por itemId

  void add(MenuItemModel item) {
    _items[item.id] = item;
    _qty.update(item.id, (v) => v + 1, ifAbsent: () => 1);
    notifyListeners();
  }

  void dec(String id) {
    if (!_qty.containsKey(id)) return;
    final v = _qty[id]! - 1;
    if (v <= 0) {
      _qty.remove(id);
      _items.remove(id);
      _specs.remove(id);
    } else {
      _qty[id] = v;
    }
    notifyListeners();
  }

  int qty(String id) => _qty[id] ?? 0;

  int get totalCents =>
      _qty.entries.fold(0, (s, e) => s + (_items[e.key]!.priceCents * e.value));

  /// Cada linea ahora incluye 'specs'
  List<Map<String, dynamic>> toOrderItems() => _qty.entries
      .map((e) => {
    'itemId': e.key,
    'name': _items[e.key]!.name,
    'unitCents': _items[e.key]!.priceCents,
    'qty': e.value,
    'lineCents': _items[e.key]!.priceCents * e.value,
    'specs': (_specs[e.key] ?? '').toString(),
  })
      .toList();

  void clear() {
    _qty.clear();
    _items.clear();
    _specs.clear();
    notifyListeners();
  }

  void setSpec(String id, String? spec) {
    if (spec == null || spec.trim().isEmpty) {
      _specs.remove(id);
    } else {
      _specs[id] = spec.trim();
    }
    notifyListeners();
  }

  String? getSpec(String id) => _specs[id];
}

class WaiterNewOrderScreen extends StatefulWidget {
  const WaiterNewOrderScreen({super.key, this.initialTable});
  final String? initialTable;

  @override
  State<WaiterNewOrderScreen> createState() => _WaiterNewOrderScreenState();
}

class _WaiterNewOrderScreenState extends State<WaiterNewOrderScreen> {
  final service = MenuService();
  String? _categoryId;
  final _tableCtrl = TextEditingController();
  bool _isTakeout = false; // false => Mesa, true => Para llevar

  @override
  void initState() {
    super.initState();
    if (widget.initialTable != null && widget.initialTable!.isNotEmpty) {
      _tableCtrl.text = widget.initialTable!;
      _isTakeout = false;
    }
  }

  @override
  void dispose() {
    _tableCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<CartController>(
      create: (_) => CartController(),
      child: Builder(builder: (context) {
        final cart = context.watch<CartController>();
        return Scaffold(
          appBar: AppBar(title: const Text('Nuevo pedido')),
          bottomNavigationBar: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              boxShadow: const [
                BoxShadow(blurRadius: 4, offset: Offset(0, -1), color: Colors.black12)
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    'Total: ${formatPEN(cart.totalCents)}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                FilledButton(
                  onPressed: cart.totalCents == 0
                      ? null
                      : () => _submit(context, cart),
                  child: const Text('Enviar'),
                ),
              ],
            ),
          ),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Tipo de pedido', style: TextStyle(fontWeight: FontWeight.w600)),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Expanded(
                                child: OutlinedButton(
                                  style: !_isTakeout
                                      ? ButtonStyle(
                                    backgroundColor: MaterialStateProperty.all(
                                        Theme.of(context).colorScheme.primaryContainer),
                                  )
                                      : null,
                                  onPressed: () => setState(() => _isTakeout = false),
                                  child: const Text('Mesa'),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: OutlinedButton(
                                  style: _isTakeout
                                      ? ButtonStyle(
                                    backgroundColor: MaterialStateProperty.all(
                                        Theme.of(context).colorScheme.primaryContainer),
                                  )
                                      : null,
                                  onPressed: () => setState(() => _isTakeout = true),
                                  child: const Text('Para llevar'),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          if (!_isTakeout)
                            TextField(
                              controller: _tableCtrl,
                              decoration: const InputDecoration(
                                labelText: 'Número de mesa',
                                border: OutlineInputBorder(),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              StreamBuilder<List<MenuCategory>>(
                stream: service.watchCategories(),
                builder: (context, snap) {
                  if (snap.hasError) {
                    return Padding(
                      padding: const EdgeInsets.all(12),
                      child: Text('Error categorías: ${snap.error}'),
                    );
                  }
                  if (!snap.hasData) {
                    return const Padding(
                      padding: EdgeInsets.all(12),
                      child: LinearProgressIndicator(),
                    );
                  }
                  final cats = snap.data!;
                  _categoryId ??= cats.isNotEmpty ? cats.first.id : null;
                  return SizedBox(
                    height: 48,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      itemBuilder: (c, i) {
                        final cgy = cats[i];
                        final sel = cgy.id == _categoryId;
                        return ChoiceChip(
                          label: Text(cgy.name),
                          selected: sel,
                          onSelected: (_) => setState(() => _categoryId = cgy.id),
                        );
                      },
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemCount: cats.length,
                    ),
                  );
                },
              ),
              Expanded(
                child: _categoryId == null
                    ? const Center(child: Text('Sin categorías'))
                    : StreamBuilder<List<MenuItemModel>>(
                  stream: service.watchItemsByCategory(_categoryId!),
                  builder: (context, snap) {
                    if (snap.hasError) {
                      return Center(child: Text('Error ítems: ${snap.error}'));
                    }
                    if (!snap.hasData) {
                      return const Center(child: CircularProgressIndicator());
                    }
                    final items = snap.data!;
                    if (items.isEmpty) {
                      return const Center(child: Text('Sin ítems'));
                    }
                    return ListView.separated(
                      padding: const EdgeInsets.all(12),
                      itemBuilder: (c, i) {
                        final it = items[i];
                        final q = cart.qty(it.id);
                        return ListTile(
                          title: Text(it.name),
                          subtitle: Text(formatPEN(it.priceCents)),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                onPressed: q > 0 ? () => cart.dec(it.id) : null,
                                icon: const Icon(Icons.remove_circle_outline),
                              ),
                              Text(q.toString()),
                              // Icono lápiz para especificaciones (opcional)
                              IconButton(
                                tooltip: 'Especificaciones (opcional)',
                                onPressed: () async {
                                  final existing = cart.getSpec(it.id) ?? '';
                                  final ctrl = TextEditingController(text: existing);
                                  final res = await showDialog<String>(
                                    context: context,
                                    builder: (ctx) => AlertDialog(
                                      title: const Text('Especificaciones (opcional)'),
                                      content: TextField(
                                        controller: ctrl,
                                        maxLines: 3,
                                        decoration: const InputDecoration(
                                          hintText: 'Ej: sin cebolla / picante / cortar en trozos',
                                        ),
                                      ),
                                      actions: [
                                        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
                                        FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text), child: const Text('Guardar')),
                                      ],
                                    ),
                                  );
                                  if (res != null) {
                                    cart.setSpec(it.id, res);
                                  }
                                },
                                icon: const Icon(Icons.edit_outlined),
                              ),
                              IconButton(
                                onPressed: () => cart.add(it),
                                icon: const Icon(Icons.add_circle_outline),
                              ),
                            ],
                          ),
                        );
                      },
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemCount: items.length,
                    );
                  },
                ),
              ),
            ],
          ),
        );
      }),
    );
  }

  // Loader bloqueante reusable
  Future<T> _withBlockingLoader<T>(Future<T> Function() task) async {
    if (!mounted) return await task();
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black45,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    try {
      final r = await task();
      return r;
    } finally {
      if (mounted) Navigator.of(context, rootNavigator: true).pop();
    }
  }

  Future<void> _submit(BuildContext context, CartController cart) async {
    final table = _tableCtrl.text.trim();
    if (!_isTakeout && table.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Ingresa la mesa')));
      return;
    }

    final items = cart.toOrderItems();
    final total = cart.totalCents;
    final db = FirebaseFirestore.instance;

    try {
      await _withBlockingLoader(() async {
        await db.collection('orders').add({
          'table': _isTakeout ? '' : table,
          'takeout': _isTakeout,
          'items': items,
          'subtotalCents': total,
          'discountCents': 0,
          'totalCents': total,
          'status': 'pendiente',
          'paymentStatus': 'pendiente',
          'payment': {
            'method': null,
            'amountCents': 0,
            'cashReceivedCents': 0,
            'changeCents': 0,
            'yapeRef': null
          },
          // mantengo notes vacío por compatibilidad con el resto del proyecto
          'notes': '',
          'createdAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
        });
      });

      cart.clear();
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al enviar: $e')),
      );
    }
  }
}

String formatPEN(int cents) => 'S/ ${(cents / 100).toStringAsFixed(2)}';
