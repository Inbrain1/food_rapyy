import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class WaiterHistoryScreen extends StatelessWidget {
  const WaiterHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final orders = FirebaseFirestore.instance.collection('orders');

    return Scaffold(
      appBar: AppBar(title: const Text('Historial de pedidos')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: orders.orderBy('paidAt', descending: true).limit(500).snapshots(),
        builder: (context, snap) {
          if (snap.hasError) {
            return Center(child: Text('Error: ${snap.error}'));
          }
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final docs = snap.data!.docs;

          // Filtra sólo pagados y con paidAt válido
          final paid = docs.where((d) {
            final data = d.data();
            final status = (data['status'] ?? '').toString();
            final paidAt = data['paidAt'];
            return status == 'pagado' && paidAt is Timestamp;
          }).toList();

          if (paid.isEmpty) {
            return const Center(child: Text('Sin pagos registrados'));
          }

          // Agrupar por día (zona local)
          final Map<DateTime, List<QueryDocumentSnapshot<Map<String, dynamic>>>> byDay = {};
          for (final d in paid) {
            final ts = d['paidAt'] as Timestamp;
            final dt = ts.toDate().toLocal();
            final dayKey = DateTime(dt.year, dt.month, dt.day);
            byDay.putIfAbsent(dayKey, () => []).add(d);
          }

          // Ordenar días descendente
          final days = byDay.keys.toList()
            ..sort((a, b) => b.compareTo(a));

          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: days.length,
            itemBuilder: (_, idx) {
              final day = days[idx];
              final list = byDay[day]!;
              final totalDay = list.fold<int>(0, (sum, d) {
                final data = d.data();
                return sum + ((data['totalCents'] ?? 0) as int);
              });

              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(_formatDay(day), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                          const Spacer(),
                          Text('Total día: ${formatPEN(totalDay)}', style: const TextStyle(fontWeight: FontWeight.w700)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      const Divider(height: 1),
                      const SizedBox(height: 8),
                      ...list.map((d) {
                        final data = d.data();
                        final table = (data['table'] ?? '').toString();
                        final total = (data['totalCents'] ?? 0) as int;
                        final paidAt = (data['paidAt'] as Timestamp).toDate().toLocal();
                        final method = (data['payment']?['method'] ?? '').toString();
                        final label = method == 'cash' ? 'Efectivo' : (method == 'yape' ? 'Yape' : 'Pago');

                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 6),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Mesa $table', style: const TextStyle(fontWeight: FontWeight.w600)),
                                    Text(_hhmm(paidAt), style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                                  ],
                                ),
                              ),
                              Text('$label · ${formatPEN(total)}'),
                            ],
                          ),
                        );
                      }),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  String _formatDay(DateTime d) {
    final dd = d.day.toString().padLeft(2, '0');
    final mm = d.month.toString().padLeft(2, '0');
    final yyyy = d.year.toString();
    return '$dd/$mm/$yyyy';
    // Si quieres nombre de día/mes con intl, puedo adaptarlo.
  }

  String _hhmm(DateTime d) {
    final hh = d.hour.toString().padLeft(2, '0');
    final mm = d.minute.toString().padLeft(2, '0');
    return '$hh:$mm';
  }
}

String formatPEN(int cents) => 'S/ ${(cents / 100).toStringAsFixed(2)}';
