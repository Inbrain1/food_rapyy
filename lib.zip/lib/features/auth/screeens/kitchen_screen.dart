import 'package:flutter/material.dart';
import '../../../core/models/kitchen_models.dart';
import '../../../core/services/auth_service.dart';
import '../../../core/services/kitchen_service.dart';

import '../../../utils/bloacking_loader.dart';
import '../widgets/kitchen_item_card.dart';

class KitchenScreen extends StatefulWidget {
  const KitchenScreen({super.key});
  @override
  State<KitchenScreen> createState() => _KitchenScreenState();
}

class _KitchenScreenState extends State<KitchenScreen> {
  final _service = KitchenService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Cocina'),
        actions: [
          IconButton(
            tooltip: 'Salir',
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await AuthService().logout();
              if (context.mounted) {
                Navigator.of(context).pushNamedAndRemoveUntil('/login', (r) => false);
              }
            },
          ),
        ],
      ),
      body: StreamBuilder<List<KitchenLine>>(
        stream: _service.watchPendingItemCards(),
        builder: (context, snap) {
          if (snap.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  'Error al cargar cocina:\n${snap.error}',
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final lines = snap.data ?? const <KitchenLine>[];
          if (lines.isEmpty) {
            return const Center(child: Text('Sin platos pendientes'));
          }

          return LayoutBuilder(
            builder: (context, c) {
              final w = c.maxWidth;
              int cross = 1;
              if (w >= 1200) cross = 4;
              else if (w >= 900) cross = 3;
              else if (w >= 650) cross = 2;

              return GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: cross,
                  childAspectRatio: 3.6,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                ),
                itemCount: lines.length,
                itemBuilder: (_, i) {
                  final line = lines[i];
                  return KitchenItemCard(
                    line: line,
                    onReady: () async {
                      await runWithBlockingLoader(context, () async {
                        await _service.markItemReady(line);
                      });
                    },
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
