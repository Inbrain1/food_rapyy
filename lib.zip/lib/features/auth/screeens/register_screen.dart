import 'package:flutter/material.dart';
import '../../../core/models/app_user.dart';
import '../../../core/services/auth_service.dart';


class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key, required this.auth, required this.onRegistered});
  final AuthService auth;
  final void Function(AppUser) onRegistered;

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _email = TextEditingController();
  final _pass = TextEditingController();
  String _role = 'waiter'; // waiter | kitchen
  bool _busy = false;

  @override
  void dispose() {
    _email.dispose();
    _pass.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Crear cuenta')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: _email, decoration: const InputDecoration(labelText: 'Email')),
            const SizedBox(height: 8),
            TextField(controller: _pass, decoration: const InputDecoration(labelText: 'Contraseña'), obscureText: true),
            const SizedBox(height: 12),
            Align(
              alignment: Alignment.centerLeft,
              child: Wrap(
                spacing: 8,
                children: [
                  FilterChip(
                    selected: _role == 'waiter',
                    onSelected: (_) => setState(() => _role = 'waiter'),
                    label: const Text('Mozo'),
                  ),
                  FilterChip(
                    selected: _role == 'kitchen',
                    onSelected: (_) => setState(() => _role = 'kitchen'),
                    label: const Text('Cocinero'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: _busy ? null : _submit,
              child: _busy ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Registrarme'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _submit() async {
    final email = _email.text.trim();
    final pass = _pass.text.trim();
    if (email.isEmpty || pass.length < 6) return;
    setState(() => _busy = true);
    try {
      final user = await widget.auth.register(email: email, password: pass, role: _role);
      widget.onRegistered(user);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }
}
