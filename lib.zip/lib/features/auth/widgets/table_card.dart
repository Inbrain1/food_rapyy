import 'package:flutter/material.dart';

class TableCard extends StatelessWidget {
  const TableCard({
    super.key,
    required this.table,
    required this.pendingCount,
    required this.items,
    required this.onOpen,
  });

  final String table;
  final int pendingCount;
  final List<String> items;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    final maxPreview = 3;
    final visible = items.take(maxPreview).toList();
    final remain = items.length - visible.length;

    return Card(
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      elevation: pendingCount > 0 ? 2 : 0.5,
      child: InkWell(
        onTap: onOpen,
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween, // <- clave
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Theme.of(context).colorScheme.outline),
                  ),
                  child: Text('Mesa $table', style: const TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),

              const SizedBox(height: 8),

              // Área de ítems que se adapta y se recorta si no hay más alto disponible
              Flexible(
                child: ClipRect(
                  child: Align(
                    alignment: Alignment.topLeft,
                    child: Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        for (final s in visible)
                          ConstrainedBox(
                            constraints: const BoxConstraints(maxWidth: 170),
                            child: Chip(
                              label: Text(
                                s,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ),
                        if (remain > 0)
                          ActionChip(
                            avatar: const Icon(Icons.more_horiz, size: 18),
                            label: Text('+$remain'),
                            onPressed: onOpen,
                          ),
                      ],
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 8),

              Align(
                alignment: Alignment.bottomRight,
                child: Chip(label: Text('pendiente ($pendingCount)')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
