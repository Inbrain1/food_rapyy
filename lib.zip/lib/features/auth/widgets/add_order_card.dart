import 'package:flutter/material.dart';

class AddOrderCard extends StatelessWidget {
  const AddOrderCard({super.key, required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.add_circle_outline, size: 42),
              SizedBox(height: 6),
              Text('Agregar pedido'),
            ],
          ),
        ),
      ),
    );
  }
}
