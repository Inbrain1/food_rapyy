import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../../core/services/orders_service.dart';
import '../../../utils/bloacking_loader.dart';
import '../screeens/waiter_new_screen.dart';
import '../screeens/waiter_order_detail_screen.dart' hide formatPEN;

Future<void> showPendingTableSheet({
  required BuildContext context,
  required String table,
  required List<QueryDocumentSnapshot<Map<String, dynamic>>> initialOrders,
}) async {
  final service = OrdersService();
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (ctx) {
      final orders = List<QueryDocumentSnapshot<Map<String, dynamic>>>.from(initialOrders);
      return StatefulBuilder(
        builder: (ctx, setStateBS) {
          Future<void> cancelOrder(QueryDocumentSnapshot<Map<String, dynamic>> d) async {
            final ok = await showDialog<bool>(
              context: ctx,
              builder: (dCtx) => AlertDialog(
                title: const Text('Cancelar pedido'),
                content: const Text('¿Seguro que deseas cancelar este pedido?'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(dCtx, false), child: const Text('No')),
                  FilledButton(onPressed: () => Navigator.pop(dCtx, true), child: const Text('Sí, cancelar')),
                ],
              ),
            );
            if (ok != true) return;

            await runWithBlockingLoader(ctx, () async {
              await service.cancelPending(d.reference);
            });
            setStateBS(() => orders.removeWhere((e) => e.id == d.id));
            if (orders.isEmpty && Navigator.of(ctx).canPop()) Navigator.of(ctx).pop();
          }

          return SafeArea(
            child: Padding(
              padding: EdgeInsets.only(
                left: 16, right: 16, top: 16,
                bottom: 16 + MediaQuery.of(ctx).viewInsets.bottom,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text('Mesa $table', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      const Spacer(),
                      FilledButton.icon(
                        onPressed: () {
                          Navigator.of(ctx).pop();
                          Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => WaiterNewOrderScreen(initialTable: table)),
                          );
                        },
                        icon: const Icon(Icons.add),
                        label: const Text('Agregar'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  if (orders.isEmpty)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 24),
                      child: Center(child: Text('Sin pendientes')),
                    )
                  else
                    Flexible(
                      child: ListView.separated(
                        shrinkWrap: true,
                        itemCount: orders.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 8),
                        itemBuilder: (_, i) {
                          final d = orders[i];
                          final data = d.data();
                          final items = (data['items'] as List?)?.cast<Map<String, dynamic>>() ?? const [];
                          final notes = (data['notes'] ?? '').toString();
                          final total = (data['totalCents'] ?? 0) as int;

                          return Card(
                            child: Padding(
                              padding: const EdgeInsets.all(12),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(formatPEN(total), style: const TextStyle(fontWeight: FontWeight.w600)),
                                  const SizedBox(height: 8),
                                  Wrap(
                                    spacing: 6,
                                    runSpacing: 6,
                                    children: [
                                      for (final it in items)
                                        Chip(label: Text('${it['name']} x${it['qty'] ?? 1}')),
                                    ],
                                  ),
                                  if (notes.isNotEmpty) ...[
                                    const SizedBox(height: 8),
                                    Row(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const Icon(Icons.note, size: 18),
                                        const SizedBox(width: 6),
                                        Expanded(child: Text(notes)),
                                      ],
                                    ),
                                  ],
                                  const SizedBox(height: 10),
                                  Row(
                                    children: [
                                      OutlinedButton.icon(
                                        onPressed: () => cancelOrder(d),
                                        icon: const Icon(Icons.close),
                                        label: const Text('Cancelar'),
                                      ),
                                      const Spacer(),
                                      FilledButton(
                                        onPressed: () {
                                          Navigator.of(ctx).pop();
                                          Navigator.of(context).push(
                                            MaterialPageRoute(
                                              builder: (_) => WaiterOrderDetailScreen(orderRef: d.reference),
                                            ),
                                          );
                                        },
                                        child: const Text('Ver / Cobrar'),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}
