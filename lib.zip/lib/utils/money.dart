String formatPEN(int cents) => 'S/ ${(cents / 100).toStringAsFixed(2)}';
