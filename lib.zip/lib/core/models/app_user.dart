// lib/models/app_user.dart
class AppUser {
  final String uid;
  final String email;
  final String role; // 'mozo' | 'cocinero'

  // Constantes para evitar typos en el rol.
  static const String kRoleMozo = 'mozo';
  static const String kRoleCocinero = 'cocinero';

  const AppUser({
    required this.uid,
    required this.email,
    required this.role,
  });

  bool get isMozo => role == kRoleMozo;
  bool get isCocinero => role == kRoleCocinero;

  Map<String, dynamic> toMap() => {
    'email': email,
    'role': role,
  };

  static AppUser fromMap(String uid, Map<String, dynamic>? map) {
    final m = map ?? const {};
    final email = (m['email'] ?? '').toString();
    final rawRole = (m['role'] ?? kRoleMozo).toString();
    final role = rawRole == kRoleCocinero ? kRoleCocinero : kRoleMozo;
    return AppUser(uid: uid, email: email, role: role);
  }

  AppUser copyWith({String? email, String? role}) =>
      AppUser(uid: uid, email: email ?? this.email, role: role ?? this.role);
}
