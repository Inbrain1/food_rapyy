import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:food_chifa/data/menu_seed.dart';
import 'core/models/app_user.dart';
import 'core/services/auth_service.dart';
import 'features/auth/screeens/kitchen_screen.dart';
import 'features/auth/screeens/login_screen.dart';
import 'features/auth/screeens/register_screen.dart';
import 'features/auth/screeens/waiter_history_screen.dart';
import 'features/auth/screeens/waiter_screen.dart';
import 'firebase_options.dart';



void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const App());

}

class App extends StatefulWidget {
  const App({super.key});
  @override
  State<App> createState() => _AppState();
}

class _AppState extends State<App> {
  final auth = AuthService();
  final GlobalKey<NavigatorState> _navKey = GlobalKey<NavigatorState>();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pedidos',
      theme: ThemeData(colorSchemeSeed: Colors.teal, useMaterial3: true),
      navigatorKey: _navKey,
      routes: {
        '/login': (_) => LoginScreen(auth: auth, onLogged: _goByRole),
        '/register': (_) => RegisterScreen(auth: auth, onRegistered: _goByRole),
        '/waiter': (_) => WaiterScreen(auth: auth),
        '/kitchen': (_) => const KitchenScreen(),
        '/waiter/history': (_) => const WaiterHistoryScreen(), // <-- NUEVA RUTA

      },
      home: AuthGate(auth: auth, goByRole: _goByRole),
      debugShowCheckedModeBanner: false,
    );
  }

  void _goByRole(AppUser user) {
    final nav = _navKey.currentState;
    if (nav == null) return;
    final route = user.role == 'kitchen' ? '/kitchen' : '/waiter';
    nav.pushNamedAndRemoveUntil(route, (r) => false);
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key, required this.auth, required this.goByRole});
  final AuthService auth;
  final void Function(AppUser) goByRole;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: auth.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (!snapshot.hasData) {
          return LoginScreen(auth: auth, onLogged: goByRole);
        }
        return FutureBuilder<AppUser?>(
          future: auth.currentAppUser(),
          builder: (context, snap) {
            if (snap.connectionState == ConnectionState.waiting) {
              return const Scaffold(body: Center(child: CircularProgressIndicator()));
            }
            final user = snap.data;
            if (user == null) {
              return RegisterScreen(auth: auth, onRegistered: goByRole);
            }
            // Render directo según rol (por si recargas el navegador)
            if (user.role == 'kitchen') {
              return const KitchenScreen();
            } else {
              return WaiterScreen(auth: auth);
            }
          },
        );
      },
    );
  }
}
